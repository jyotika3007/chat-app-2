function test(){
    console.log('Testing');
}